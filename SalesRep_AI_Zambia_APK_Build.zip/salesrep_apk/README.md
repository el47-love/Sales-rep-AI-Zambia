# SalesRep AI Zambia: build the APK on GitHub (free)

1. Create a free account at https://github.com and click "New repository".
   Name it salesrep-ai and keep it Private.
2. Upload this whole folder. Include the hidden `.github` folder:
   on the repository page click "Add file" > "Upload files" and drag in
   main.py, buildozer.spec, README.md and the `.github` folder.
   (On a computer you can also use Git to push the folder.)
3. Open the "Actions" tab. The "Build Android APK" workflow starts
   automatically. The first build takes about 40 to 60 minutes.
4. When it shows a green tick, open that run, scroll to "Artifacts" and
   download SalesRep-AI-APK. It is a zip file containing the .apk.
5. On your phone, open the downloaded file and install it. Android will ask
   you to allow installing from your browser or file manager. Allow it once.

Notes
- The app keeps your data in its own storage on the phone. Your Pydroid 3
  data is NOT moved automatically. Use Settings > Export database backup in
  Pydroid, then copy the backup file to the phone's Download folder, and
  restore it manually if you need the old records.
- To change the app later, edit main.py, upload it again, and a new APK builds.
- The version is set in buildozer.spec (version = 2.3).
